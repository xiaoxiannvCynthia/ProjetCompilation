(* bla bla *)
(* bli 
 * bli *)
let x = (* bla *) 1 in 2
